#include "general.h"
#include "encabezados.h"

void realizar_deposito(int id_cuenta, const char *ruta_cuentas, const char *ruta_log);
void realizar_retiro(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_retiro);
void realizar_transferencia(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_transferencia);
void consultar_saldo(int id_cuenta, const char *ruta_cuentas);
void ejecutar_menu_usuario(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_retiro, int limite_transferencia);

int main() {
    Config config = leer_configuracion("config.log");
    
    int id_cuenta;
    const char *ruta_cuentas = config.archivo_cuentas;
    const char *ruta_log = config.archivo_log;
    int limite_retiro = config.limite_retiro;
    int limite_transferencia = config.limite_transferencia;
    
    id_cuenta = 1001;  // Corrección: Usar = en lugar de == para asignación
    
    ejecutar_menu_usuario(id_cuenta, ruta_cuentas, ruta_log, limite_retiro, limite_transferencia);
    return 0;
}

Config leer_configuracion(const char *ruta) {
    FILE *archivo = fopen(ruta, "r");
    if (archivo == NULL) {
        perror("Error al abrir config.log");
        exit(1);
    }
    
    Config config;
    char linea[100];
    while (fgets(linea, sizeof(linea), archivo)) {
        if (linea[0] == '#' || strlen(linea) < 3)
            continue; // Ignorar comentarios y líneas vacías
        
        if (strstr(linea, "LIMITE_RETIRO"))
            sscanf(linea, "LIMITE_RETIRO = %d", &config.limite_retiro);
        else if (strstr(linea, "LIMITE_TRANSFERENCIA"))
            sscanf(linea, "LIMITE_TRANSFERENCIA = %d-    sscanf(linea, "UMBRAL_DE_RETIROS"))
            sscanf(linea, "UMBRAL_DE_RETIROS = %d", &config.umbral_retiros);
        else if (strstr(linea, "UMBRAL_TRANSFERENCIAS"))
            sscanf(linea, "UMBRAL_TRANSFERENCIAS = %d", &config.umbral_transferencias);
        else if (strstr(linea, "NUM_HILOS"))
            sscanf(linea, "NUM_HILOS = %d", &config.num_hilos);
        else if (strstr(linea, "ARCHIVO_CUENTAS"))
            sscanf(linea, "ARCHIVO_CUENTAS = %s", config.archivo_cuentas);
        else if (strstr(linea, "ARCHIVO_LOG"))
            sscanf(linea, "ARCHIVO_LOG = %s", config.archivo_log);
    }
    fclose(archivo);
    return config;
}

void ejecutar_menu_usuario(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_retiro, int limite_transferencia) {
    int opcion = 0;
    while (1) {
        printf("\n-------------------------------\n");
        printf("1. Depósito\n2. Retiro\n3. Transferencia\n4. Consultar saldo\n5. Salir\n");
        printf("-------------------------------\n");
        printf("Seleccione una opción: ");
        
        while (getchar() != '\n');
        
        // Leer la entrada del usuario
        if (scanf("%d", &opcion) != 1) {
            printf("Entrada no válida. Por favor, ingrese un número.\n");
            while (getchar() != '\n');
            continue;
        }
        
        printf("%d", opcion);
        
        while (getchar() != '\n');
        
        switch (opcion) {
            case 1: realizar_deposito(id_cuenta, ruta_cuentas, ruta_log); break;
            case 2: realizar_retiro(id_cuenta, ruta_cuentas, ruta_log, limite_retiro); break;
            case 3: realizar_transferencia(id_cuenta, ruta_cuentas, ruta_log, limite_transferencia); break;
            case 4: consultar_saldo(id_cuenta, ruta_cuentas); break;
            case 5: printf("Saliendo...\n"); return;
            default: printf("Opción no válida. Intente de nuevo.\n");
        }
    }
}

void realizar_deposito(int id_cuenta, const char *ruta_cuentas, const char *ruta_log) {
    float monto;
    printf("Ingrese el monto a depositar: ");
    scanf("%f", &monto);
    
    if (monto <= 0) {
        printf("El monto debe ser mayor que cero.\n");
        return;
    }
    
    // Abrir archivo de cuentas
    FILE *archivo = fopen(ruta_cuentas, "r+");
    if (archivo == NULL) {
        perror("Error al abrir archivo de cuentas");
        return;
    }
    
    Cuenta cuenta;
    int encontrado = 0;
    char linea[100];
    long posicion;
    
    // Buscar la cuenta
    while (fgets(linea, sizeof(linea), archivo)) {
        posicion = ftell(archivo) - strlen(linea); // Guardar la posición de inicio de la línea
        sscanf(linea, "%d,%49[^,],%f,%d", &cuenta.numero_cuenta, cuenta.titular, &cuenta.saldo, &cuenta.num_transacciones);
        
        if (cuenta.numero_cuenta == id_cuenta) {
            encontrado = 1;
            cuenta.saldo += monto; // Actualizar saldo
            cuenta.num_transacciones++; // Incrementar número de transacciones
            printf("Depósito realizado con éxito. Nuevo saldo: %.2f\n", cuenta.saldo);
            
            // Volver a la posición y escribir la cuenta actualizada
            fseek(archivo, posicion, SEEK_SET);
            fprintf(archivo, "%d,%s,%.2f,%d\n", cuenta.numero_cuenta, cuenta.titular, cuenta.saldo, cuenta.num_transacciones);
            break;
        }
    }
    fclose(archivo);
    
    if (encontrado) {
        // Log de la operación
        FILE *log = fopen(ruta_log, "a");
        if (log) {
            fprintf(log, "Depósito: Cuenta %d, Monto: %.2f\n", id_cuenta, monto);
            fclose(log);
        }
    } else {
        printf("Cuenta no encontrada.\n");
    }
}

void realizar_retiro(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_retiro) {
    float monto;
    printf("Ingrese el monto a retirar: ");
    scanf("%f", &monto);
    
    if (monto <= 0 || monto > limite_retiro) {
        printf("El monto debe ser mayor que cero y no exceder el límite de retiro.\n");
        return;
    }
    
    // Abrir archivo de cuentas
    FILE *archivo = fopen(ruta_cuentas, "r");
    if (archivo == NULL) {
        perror("Error al abrir archivo de cuentas");
        return;
    }
    
    Cuenta cuenta;
    int encontrado = 0;
    char linea[100]; // Buffer para leer líneas del archivo
    
    // Crear un archivo temporal para escribir los cambios
    FILE *archivo_temp = fopen("temp.txt", "w");
    if (archivo_temp == NULL) {
        perror("Error al crear archivo temporal");
        fclose(archivo);
        return;
    }
    
    // Buscar la cuenta
    while (fgets(linea, sizeof(linea), archivo)) {
        // Parsear la línea
        sscanf(linea, "%d,%49[^,],%f,%d", &cuenta.numero_cuenta, cuenta.titular, &cuenta.saldo, &cuenta.num_transacciones);
        
        if (cuenta.numero_cuenta == id_cuenta) {
            encontrado = 1;
            if (cuenta.saldo >= monto) {
                cuenta.saldo -= monto; // Actualizar saldo
                cuenta.num_transacciones++; // Incrementar número de transacciones
                printf("Retiro realizado con éxito. Nuevo saldo: %.2f\n", cuenta.saldo);
            } else {
                printf("Saldo insuficiente para realizar el retiro.\n");
                fclose(archivo);
                fclose(archivo_temp);
                return;
            }
        }
        
        // Escribir la cuenta (actualizada o no) en el archivo temporal
        fprintf(archivo_temp, "%d,%s,%.2f,%d\n", cuenta.numero_cuenta, cuenta.titular, cuenta.saldo, cuenta.num_transacciones);
    }
    
    fclose(archivo);
    fclose(archivo_temp);
    
    // Reemplazar el archivo original con el temporal
    remove(ruta_cuentas); // Eliminar el archivo original
    rename("temp.txt", ruta_cuentas); // Renombrar el archivo temporal
    
    if (encontrado) {
        // Log de la operación
        FILE *log = fopen(ruta_log, "a");
        if (log) {
            fprintf(log, "Retiro: Cuenta %d, Monto: %.2f\n", id_cuenta, monto);
            fclose(log);
        }
    } else {
        printf("Cuenta no encontrada.\n");
    }
}

void realizar_transferencia(int id_cuenta, const char *ruta_cuentas, const char *ruta_log, int limite_transferencia) {
    int cuenta_destino;
    float monto;
    printf("Ingrese el ID de la cuenta destino: ");
    scanf("%d", &cuenta_destino);
    printf("Ingrese el monto a transferir: ");
    scanf("%f", &monto);
    
    if (monto <= 0 || monto > limite_transferencia) {
        printf("El monto debe ser mayor que cero y no exceder el límite de transferencia.\n");
        return;
    }
    
    // Abrir archivo de cuentas
    FILE *archivo = fopen(ruta_cuentas, "r");
    if (archivo == NULL) {
        perror("Error al abrir archivo de cuentas");
        return;
    }
    
    Cuenta cuenta_origen, cuenta_dest;
    int encontrado_origen = 0, encontrado_dest = 0;
    char linea[100]; // Buffer para leer líneas del archivo
    
    // Crear un archivo temporal para escribir los cambios
    FILE *archivo_temp = fopen("temp.txt", "w");
    if (archivo_temp == NULL) {
        perror("Error al crear archivo temporal");
        fclose(archivo);
        return;
    }
    
    // Buscar la cuenta origen
    while (fgets(linea, sizeof(linea), archivo)) {
        sscanf(linea, "%d,%49[^,],%f,%d", &cuenta_origen.numero_cuenta, cuenta_origen.titular, &cuenta_origen.saldo, &cuenta_origen.num_transacciones);
        
        if (cuenta_origen.numero_cuenta == id_cuenta) {
            encontrado_origen = 1;
            if (cuenta_origen.saldo >= monto) {
                cuenta_origen.saldo -= monto; // Actualizar saldo de la cuenta origen
                cuenta_origen.num_transacciones++; // Incrementar número de transacciones
            } else {
                printf("Saldo insuficiente para realizar la transferencia.\n");
                fclose(archivo);
                fclose(archivo_temp);
                return;
            }
        }
        
        // Escribir la cuenta (actualizada o no) en el archivo temporal
        fprintf(archivo_temp, "%d,%s,%.2f,%d\n", cuenta_origen.numero_cuenta, cuenta_origen.titular, cuenta_origen.saldo, cuenta_origen.num_transacciones);
    }
    
    // Volver al inicio del archivo para buscar la cuenta destino
    rewind(archivo); // Volver al inicio del archivo
    
    // Buscar la cuenta destino
    while (fgets(linea, sizeof(linea), archivo)) {
        // Parsear la línea
        sscanf(linea, "%d,%49[^,],%f,%d", &cuenta_dest.numero_cuenta, cuenta_dest.titular, &cuenta_dest.saldo, &cuenta_dest.num_transacciones);
        
        if (cuenta_dest.numero_cuenta == cuenta_destino) {
            encontrado_dest = 1;
            cuenta_dest.saldo += monto; // Actualizar saldo de la cuenta destino
            cuenta_dest.num_transacciones++; // Incrementar número de transacciones
        }
        
        // Escribir la cuenta (actualizada o no) en el archivo temporal
        fprintf(archivo_temp, "%d,%s,%.2f,%d\n", cuenta_dest.numero_cuenta, cuenta_dest.titular, cuenta_dest.saldo, cuenta_dest.num_transacciones);
    }
    
    fclose(archivo);
    fclose(archivo_temp);
    
    // Reemplazar el archivo original con el temporal
    remove(ruta_cuentas); // Eliminar el archivo original
    rename("temp.txt", ruta_cuentas); // Renombrar el archivo temporal
    
    if (encontrado_origen && encontrado_dest) {
        // Log de la operación
        FILE *log = fopen(ruta_log, "a");
        if (log) {
            fprintf(log, "Transferencia: Cuenta Origen %d, Cuenta Destino %d, Monto: %.2f\n", id_cuenta, cuenta_destino, monto);
            fclose(log);
        }
        printf("Transferencia realizada con éxito. Nuevo saldo cuenta origen: %.2f, cuenta destino: %.2f\n", cuenta_origen.saldo, cuenta_dest.saldo);
    } else {
        printf("Una de las cuentas no fue encontrada.\n");
    }
}

void consultar_saldo(int id_cuenta, const char *ruta_cuentas) {
    // Abrir archivo de cuentas
    FILE *archivo = fopen(ruta_cuentas, "r");
    if (archivo == NULL) {
        perror("Error al abrir archivo de cuentas");
        return;
    }
    
    Cuenta cuenta;
    int encontrado = 0;
    char linea[100]; // Buffer para leer líneas del archivo
    
    // Buscar la cuenta
    while (fgets(linea, sizeof(linea), archivo)) {
        // Parsear la línea
        sscanf(linea, "%d,%49[^,],%f,%d", &cuenta.numero_cuenta, cuenta.titular, &cuenta.saldo, &cuenta.num_transacciones);
        
        if (cuenta.numero_cuenta == id_cuenta) {
            encontrado = 1;
            printf("Saldo de la cuenta %d: %.2f\n", id_cuenta, cuenta.saldo);
            break;
        }
    }
    
    fclose(archivo);
    
    if (!encontrado) {
        printf("Cuenta no encontrada.\n");
    }
}