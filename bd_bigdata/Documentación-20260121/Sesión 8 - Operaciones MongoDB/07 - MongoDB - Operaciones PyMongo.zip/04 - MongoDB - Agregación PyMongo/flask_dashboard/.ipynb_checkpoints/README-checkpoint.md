# Dashboard Flask + MongoDB

Pequeña app Flask para visualizar y explorar las colecciones `clientes` y `compras` del taller. Usa PyMongo contra `LabTestDB`, muestra métricas, gráficos (Chart.js), tablas y un EDA con pandas profiling.

*Autor: Marlon Cárdenas (@mCardenas) - 2025*

## Estructura
- `app.py`: rutas Flask (`/`, `/clientes`, `/compras`).
- `config.py`: variables de entorno (`MONGODB_URI`, `MONGODB_DB`).
- `db.py`: conexión a MongoDB con ping inicial.
- `services.py`: consultas y agregados (conteos, top ciudades, top métodos, recientes, ventas por mes, compras por estatus) y helper para DataFrame.
- `templates/`: `base.html`, `index.html`, `clientes.html`, `compras.html`, `eda.html` (Bootstrap 5 + Chart.js + profiling embebido).
- `static/css/styles.css`: estilos ligeros tipo dashboard.
- `scripts/seed.py`: carga los JSON de `../data` en Mongo.
- `.env.example`: ejemplo de configuración.

## Requisitos
- Python 3.10+
- MongoDB en marcha (local o Atlas)
- Dependencias: `flask`, `pymongo`, `python-dotenv`
- Dependencias: `flask`, `pymongo`, `python-dotenv`, `pandas`, `ydata-profiling`

## Instalación rápida
```powershell
cd "e:\EUnidad\UNIR\Bases de Datos Big Data\Material de Clases\Clase 6\04 - MongoDB - Agregación PyMongo\flask_dashboard"
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env  # ajusta MONGODB_URI/MONGODB_DB si lo necesitas
```

## Semillas (datos de `data/`)
Ejecuta para cargar las colecciones desde los JSON de la carpeta raíz `data/`:
```powershell
python scripts/seed.py
```

## Ejecutar la app
```powershell
set FLASK_APP=app.py
python app.py
```
Abre http://localhost:5000

## Qué muestra el dashboard
- Tarjetas con total de clientes, compras, monto vendido y ticket promedio.
- Gráficos (Chart.js):
	- Top ciudades (barra)
	- Top métodos de pago (doughnut)
	- Ventas por mes (línea)
	- Compras por estatus (barra)
- Compras recientes (cliente, fecha, método, estatus, total).
- Vista de clientes (ID, nombre, email, ciudad, estatus, puntos).
- Vista de compras con filtro por `estatus` (entregado/pendiente/en_proceso/cancelado).
- Página de EDA `/eda` con pandas profiling (selecciona colección y límite de filas, genera reporte HTML embebido).

## EDA (pandas profiling)
- Ruta: http://localhost:5000/eda
- Parámetros: `dataset` (`clientes`|`compras`), `limit` (por defecto 500).
- Usa `minimal=True` para agilizar el perfil; si pesa mucho, baja el `limit` (ej. 300-500).

## Notas
- Las fechas se muestran tal cual vienen del documento (`$date`); puedes formatearlas en Jinja si lo deseas.
- Si usas Atlas, pon tu URI SRV en `.env`.
- Si no hay datos, las tablas muestran mensajes vacíos en lugar de romper la vista.
- Para profiling, evita límites muy altos en máquinas modestas; comienza con 300-500 filas.
